# default rules yetarli
