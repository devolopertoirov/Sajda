package uz.tasbehduo.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField
import java.util.TimeZone
import kotlin.math.*

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun str(c: Context, k: String, d: String) = sp(c).getString(k, d) ?: d
    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun put(c: Context, k: String, v: Any) {
        val e = sp(c).edit()
        when (v) {
            is String -> e.putString(k, v)
            is Int -> e.putInt(k, v)
            is Boolean -> e.putBoolean(k, v)
        }
        e.apply()
    }
}

// ---------- TIL ----------
// uz = eski lotin (o' g'), uzn = yangi lotin (oʻ gʻ), uzc = Ўзбекча, en, ru
val LANGS = listOf(
    "uz" to "O'zbekcha (eski lotin)", "uzn" to "Oʻzbekcha (yangi lotin)",
    "uzc" to "Ўзбекча", "en" to "English", "ru" to "Русский"
)
var langState by mutableStateOf("uz")
fun loadLang(c: Context) { langState = Prefs.str(c, "lang", "uz") }

fun fixLatin(s: String) = s.replace("o'", "o\u02BB").replace("g'", "g\u02BB").replace("O'", "O\u02BB").replace("G'", "G\u02BB")

fun toCyr(s: String): String {
    val sb = StringBuilder(); var i = 0
    while (i < s.length) {
        val ch = s[i]; val l = ch.lowercaseChar()
        val n = if (i + 1 < s.length) s[i + 1].lowercaseChar() else ' '
        val up = ch.isUpperCase()
        val prevLetter = i > 0 && s[i - 1].isLetter()
        var skip = 1
        val out: String = when {
            l == 'o' && n == '\'' -> { skip = 2; "ў" }
            l == 'g' && n == '\'' -> { skip = 2; "ғ" }
            l == 's' && n == 'h' -> { skip = 2; "ш" }
            l == 'c' && n == 'h' -> { skip = 2; "ч" }
            l == 'y' && n == 'o' -> { skip = 2; "ё" }
            l == 'y' && n == 'u' -> { skip = 2; "ю" }
            l == 'y' && n == 'a' -> { skip = 2; "я" }
            l == 'e' && !prevLetter -> "э"
            else -> when (l) {
                'a' -> "а"; 'b' -> "б"; 'd' -> "д"; 'e' -> "е"; 'f' -> "ф"; 'g' -> "г"; 'h' -> "ҳ"
                'i' -> "и"; 'j' -> "ж"; 'k' -> "к"; 'l' -> "л"; 'm' -> "м"; 'n' -> "н"; 'o' -> "о"
                'p' -> "п"; 'q' -> "қ"; 'r' -> "р"; 's' -> "с"; 't' -> "т"; 'u' -> "у"; 'v' -> "в"
                'x' -> "х"; 'y' -> "й"; 'z' -> "з"; '\'' -> "ъ"; '\u02BB' -> "ъ"
                else -> ch.toString()
            }
        }
        sb.append(if (up && out.isNotEmpty() && out[0].isLetter()) out.replaceFirstChar { it.uppercase() } else out)
        i += skip
    }
    return sb.toString()
}

fun uzt(s: String) = when (langState) { "uzn" -> fixLatin(s); "uzc" -> toCyr(s); else -> s }
fun tr(uz: String, en: String, ru: String) = when (langState) { "en" -> en; "ru" -> ru; else -> uzt(uz) }
fun pick(l: List<String>) = when (langState) { "en" -> l[1]; "ru" -> l[2]; else -> uzt(l[0]) }

fun pName(i: Int) = when (i) {
    0 -> tr("Bomdod", "Fajr", "Фаджр")
    1 -> tr("Quyosh", "Sunrise", "Восход")
    2 -> tr("Peshin", "Dhuhr", "Зухр")
    3 -> tr("Asr", "Asr", "Аср")
    4 -> tr("Shom", "Maghrib", "Магриб")
    else -> tr("Xufton", "Isha", "Иша")
}
fun fmt(m: Int) = "%02d:%02d".format(((m / 60) % 24 + 24) % 24, ((m % 60) + 60) % 60)

fun hijri(c: Context): String {
    val d = HijrahDate.from(LocalDate.now().plusDays(Prefs.int(c, "hadj", 0).toLong()))
    val m = listOf("Muharram", "Safar", "Rabiul avval", "Rabiul oxir", "Jumodul avval", "Jumodul oxir",
        "Rajab", "Sha'bon", "Ramazon", "Shavvol", "Zulqa'da", "Zulhijja")
    return "${d.get(ChronoField.DAY_OF_MONTH)} ${uzt(m[d.get(ChronoField.MONTH_OF_YEAR) - 1])}, ${d.get(ChronoField.YEAR)}"
}

// ---------- JOYLASHUV ----------
data class City(val name: String, val lat: Double, val lng: Double)
val CITIES = listOf(
    City("Toshkent", 41.3111, 69.2797), City("Samarqand", 39.6542, 66.9597), City("Buxoro", 39.7747, 64.4286),
    City("Andijon", 40.7821, 72.3442), City("Namangan", 41.0011, 71.6683), City("Farg'ona", 40.3842, 71.7843),
    City("Qo'qon", 40.5286, 70.9425), City("Nukus", 42.4531, 59.6103), City("Urganch", 41.5500, 60.6333),
    City("Xiva", 41.3783, 60.3639), City("Gurlan", 41.8450, 60.3900), City("Qarshi", 38.8606, 65.7891),
    City("Termiz", 37.2242, 67.2783), City("Jizzax", 40.1158, 67.8422), City("Guliston", 40.4897, 68.7842),
    City("Navoiy", 40.0844, 65.3792)
)
object Loc {
    fun get(c: Context): Triple<String, Double, Double> {
        if (Prefs.str(c, "mode", "city") == "gps") {
            val la = Prefs.str(c, "lat", "").toDoubleOrNull(); val ln = Prefs.str(c, "lng", "").toDoubleOrNull()
            if (la != null && ln != null) return Triple("GPS", la, ln)
        }
        val ct = CITIES.firstOrNull { it.name == Prefs.str(c, "city", "Toshkent") } ?: CITIES[0]
        return Triple(ct.name, ct.lat, ct.lng)
    }
}

// ---------- NAMOZ HISOBI (oflayn) ----------
// Tekshirildi: Gurlan, 26.10.2026 — Bomdod 18°, Xufton 18°, Hanafi Asr, Shom +5 daq. rasmdagi jadvalga mos.
object Calc {
    fun hours(d: LocalDate, lat: Double, lng: Double, fa: Double, ia: Double, hanafi: Boolean): DoubleArray {
        val jd = d.toEpochDay() + 2440587.5
        val tz = TimeZone.getDefault().getOffset(d.toEpochDay() * 86400000L + 43200000L) / 3600000.0
        val n = jd + 0.5 - lng / 360 - 2451545.0
        val g = Math.toRadians((357.529 + 0.98560028 * n) % 360)
        val q = (280.459 + 0.98564736 * n) % 360
        val L = Math.toRadians((q + 1.915 * sin(g) + 0.020 * sin(2 * g)) % 360)
        val e = Math.toRadians(23.439 - 0.00000036 * n)
        var ra = Math.toDegrees(atan2(cos(e) * sin(L), cos(L))) / 15
        ra = ((ra % 24) + 24) % 24
        val dec = asin(sin(e) * sin(L))
        var eqt = q / 15 - ra
        if (eqt > 12) eqt -= 24
        if (eqt < -12) eqt += 24
        val noon = 12 + tz - lng / 15 - eqt
        val la = Math.toRadians(lat)
        fun ang(a: Double) = Math.toDegrees(acos(((-sin(Math.toRadians(a)) - sin(la) * sin(dec)) / (cos(la) * cos(dec))).coerceIn(-1.0, 1.0))) / 15
        val aa = atan(1 / ((if (hanafi) 2.0 else 1.0) + tan(abs(la - dec))))
        val asr = Math.toDegrees(acos(((sin(aa) - sin(la) * sin(dec)) / (cos(la) * cos(dec))).coerceIn(-1.0, 1.0))) / 15
        return doubleArrayOf(noon - ang(fa), noon - ang(0.833), noon, noon + asr, noon + ang(0.833), noon + ang(ia))
    }
}

fun qiblaBearing(lat: Double, lng: Double): Double {
    val p1 = Math.toRadians(lat); val p2 = Math.toRadians(21.4225); val dl = Math.toRadians(39.8262 - lng)
    val y = sin(dl) * cos(p2)
    val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
    return (Math.toDegrees(atan2(y, x)) + 360) % 360
}
