package uz.tasbehduo.app

// Duolar: ishonchli manbadan TEKSHIRIB chiqing (arabcha, o'qilishi, tarjima). [uz, en, ru]
class Dua(val title: List<String>, val ar: String, val lat: String, val tr: List<String>)

val DUAS = listOf(
    Dua(listOf("Taom oldidan", "Before eating", "Перед едой"), "بِسْمِ اللّٰهِ", "Bismillah",
        listOf("Alloh nomi bilan (boshlayman).", "In the name of Allah.", "С именем Аллаха.")),
    Dua(listOf("Taomdan keyin", "After eating", "После еды"),
        "الْحَمْدُ لِلّٰهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ",
        "Alhamdu lillahil-lazi at'amana va saqona va ja'alana muslimin",
        listOf("Bizni taomlantirgan, sug'organ va musulmon qilgan Allohga hamd bo'lsin.",
            "Praise be to Allah who fed us, gave us drink, and made us Muslims.",
            "Хвала Аллаху, который накормил нас, напоил и сделал нас мусульманами.")),
    Dua(listOf("Uxlashdan oldin", "Before sleeping", "Перед сном"),
        "بِاسْمِكَ اللّٰهُمَّ أَمُوتُ وَأَحْيَا", "Bismika Allohumma amutu va ahya",
        listOf("Ey Alloh, Sening noming bilan o'laman va tirilaman.",
            "O Allah, in Your name I die and I live.", "С Твоим именем, о Аллах, я умираю и оживаю.")),
    Dua(listOf("Uyg'onganda", "Upon waking", "После пробуждения"),
        "الْحَمْدُ لِلّٰهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ",
        "Alhamdu lillahil-lazi ahyana ba'da ma amatana va ilayhin-nushur",
        listOf("Bizni o'ldirganidan keyin tiriltirgan Allohga hamd bo'lsin, qaytish Unga.",
            "Praise be to Allah who gave us life after causing us to die, and to Him is the resurrection.",
            "Хвала Аллаху, Который оживил нас после того, как умертвил, и к Нему воскрешение.")),
    Dua(listOf("Uydan chiqishda", "Leaving home", "При выходе из дома"),
        "بِسْمِ اللّٰهِ تَوَكَّلْتُ عَلَى اللّٰهِ وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللّٰهِ",
        "Bismillahi tavakkaltu alallohi va la havla va la quvvata illa billah",
        listOf("Alloh nomi bilan, Allohga tavakkal qildim; kuch-quvvat faqat Alloh bilandir.",
            "In the name of Allah, I trust in Allah; there is no power or strength except with Allah.",
            "С именем Аллаха, уповаю на Аллаха; нет мощи и силы ни у кого, кроме Аллаха.")),
    Dua(listOf("Safar duosi", "Travel", "В дорогу"),
        "سُبْحَانَ الَّذِي سَخَّرَ لَنَا هٰذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَىٰ رَبِّنَا لَمُنْقَلِبُونَ",
        "Subhanallazi sakhkhara lana hazo va ma kunna lahu muqrinin va inna ila Rabbina la munqalibun",
        listOf("Buni bizga bo'ysundirgan Zot pokdir; biz unga qodir emas edik. Albatta, biz Robbimizga qaytuvchimiz.",
            "Glory to Him who subjected this to us, and we could not have done it ourselves. And to our Lord we will return.",
            "Пречист Тот, Кто подчинил нам это, а мы не смогли бы сделать этого сами; и к нашему Господу мы вернёмся.")),
    Dua(listOf("Rabbana atina", "Rabbana atina", "Раббана атина"),
        "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
        "Rabbana atina fid-dunya hasanatan va fil-axirati hasanatan va qina azaban-nar",
        listOf("Robbimiz, bizga dunyoda ham yaxshilik, oxiratda ham yaxshilik ber va bizni do'zax azobidan asra.",
            "Our Lord, give us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.",
            "Господь наш! Даруй нам добро в этом мире и добро в Последней жизни и защити нас от мук Огня.")),
    Dua(listOf("Istig'for", "Seeking forgiveness", "Истигфар"),
        "أَسْتَغْفِرُ اللّٰهَ الْعَظِيمَ الَّذِي لَا إِلٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ",
        "Astag'firulloh al-azim alladhi la ilaha illa huval-hayyul-qayyum va atubu ilayh",
        listOf("Undan boshqa iloh yo'q, tirik va qoim Buyuk Allohdan mag'firat so'rayman va Unga tavba qilaman.",
            "I seek forgiveness from Allah the Great, there is no god but Him, the Ever-Living, the Sustainer, and I repent to Him.",
            "Прошу прощения у Аллаха Великого, нет божества кроме Него, Живого, Вечносущего, и каюсь перед Ним."))
)

// Zikrlar: arabcha, o'qilishi, odatdagi son
class Zikr(val ar: String, val lat: String, val target: Int)
val ZIKRS = listOf(
    Zikr("سُبْحَانَ اللّٰهِ", "Subhanalloh", 33),
    Zikr("الْحَمْدُ لِلّٰهِ", "Alhamdulillah", 33),
    Zikr("اللّٰهُ أَكْبَرُ", "Allohu akbar", 33),
    Zikr("لَا إِلٰهَ إِلَّا اللّٰهُ", "La ilaha illalloh", 100),
    Zikr("أَسْتَغْفِرُ اللّٰهَ", "Astag'firulloh", 100),
    Zikr("صَلَّى اللّٰهُ عَلَيْهِ وَسَلَّمَ", "Sallallohu alayhi va sallam", 100)
)
