package uz.tasbehduo.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.widget.Toast
import java.io.File
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadLang(this)
        MobileAds.initialize(this) {}
        Sched.schedule(this)
        setContent { AppTheme { Root() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val cs = if (isSystemInDarkTheme()) darkColorScheme(
        primary = Color(0xFFD4B35A), onPrimary = Color.Black, background = Color(0xFF0E1F1A),
        surface = Color(0xFF16302A), onSurface = Color(0xFFEFEFE6), onBackground = Color(0xFFEFEFE6),
        secondaryContainer = Color(0xFF244A40), onSecondaryContainer = Color(0xFFEFEFE6)
    ) else lightColorScheme(
        primary = Color(0xFF14594A), onPrimary = Color.White, background = Color(0xFFF6F3EA),
        surface = Color.White, secondaryContainer = Color(0xFFCFE6DC)
    )
    MaterialTheme(colorScheme = cs, content = content)
}

@Composable
fun Banner() {
    AndroidView(modifier = Modifier.fillMaxWidth(), factory = { ctx ->
        AdView(ctx).apply {
            setAdSize(AdSize.BANNER)
            // Debug (sinov) build: test reklama; release (Play Market): haqiqiy reklama. O'z reklamangizni bosmang!
            adUnitId = if (BuildConfig.DEBUG) "ca-app-pub-3940256099942544/6300978111" else "ca-app-pub-3556340465144253/2497400236"
            loadAd(AdRequest.Builder().build())
        }
    })
}

@Composable
fun Root() {
    var tab by remember { mutableIntStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }
    val items = listOf(
        "🕌" to tr("Namoz", "Prayer", "Намаз"), "🧭" to tr("Qibla", "Qibla", "Кибла"),
        "📿" to tr("Tasbeh", "Tasbih", "Тасбих"), "📗" to tr("Qur'on", "Quran", "Коран"), "📖" to tr("Duo", "Dua", "Дуа"),
        "⚙️" to tr("Sozlama", "Settings", "Настройки")
    )
    Scaffold(containerColor = MaterialTheme.colorScheme.background, bottomBar = {
        Column {
            Banner() // faqat pastki banner
            NavigationBar {
                items.forEachIndexed { i, (ic, label) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Text(ic, fontSize = 20.sp) }, label = { Text(label, maxLines = 1, fontSize = 10.sp) })
                }
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) { 0 -> PrayerScreen(); 1 -> QiblaScreen(); 2 -> TasbehScreen(); 3 -> QuranScreen(); 4 -> DuaScreen(); else -> SettingsScreen() }
        }
    }
}

fun requestGps(c: Context, done: () -> Unit) {
    try {
        LocationServices.getFusedLocationProviderClient(c)
            .getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
            .addOnSuccessListener { loc ->
                if (loc != null) {
                    Prefs.put(c, "mode", "gps"); Prefs.put(c, "lat", loc.latitude.toString()); Prefs.put(c, "lng", loc.longitude.toString())
                    Sched.schedule(c); PrayerWidget.refresh(c); done()
                }
            }
    } catch (e: SecurityException) { }
}

// ---------------- NAMOZ ----------------
@Composable
fun PrayerScreen() {
    val c = LocalContext.current
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); tick = System.currentTimeMillis() } }
    var ver by remember { mutableIntStateOf(0) }
    var showCity by remember { mutableStateOf(false) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) requestGps(c) { ver++ } }
    val today = LocalDate.now()
    val times = remember(ver, today) { Sched.minutes(c, today) }
    val place = remember(ver) { Loc.get(c) }
    val zone = ZoneId.systemDefault()
    val startToday = today.atStartOfDay(zone).toInstant().toEpochMilli()
    var nextI = -1; var nextMs = 0L
    for (i in 0..5) { val ms = startToday + times[i] * 60000L; if (ms > tick) { nextI = i; nextMs = ms; break } }
    if (nextI < 0) {
        nextI = 0
        nextMs = today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli() + Sched.minutes(c, today.plusDays(1))[0] * 60000L
    }
    val left = ((nextMs - tick) / 1000).coerceAtLeast(0)
    val loc = Locale.forLanguageTag(when (langState) { "en" -> "en"; "ru" -> "ru"; "uzc" -> "uz-Cyrl"; else -> "uz" })

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("📍 ${if (place.first == "GPS") "GPS" else uzt(place.first)}  ▾", fontSize = 20.sp, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { showCity = true })
        Text(hijri(c), fontSize = 15.sp)
        Text(today.format(DateTimeFormatter.ofPattern("EEEE, d-MMMM", loc)), fontSize = 14.sp)
        val am = c.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            Spacer(Modifier.height(8.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF8A3B2E))) {
                Column(Modifier.padding(12.dp)) {
                    Text(tr("Azon o'z vaqtida va tanlangan ovoz bilan chalinishi uchun «Aniq signal» ruxsatini bering.",
                        "Allow «Exact alarms» so the adhan plays on time with your chosen sound.",
                        "Разрешите «Точные будильники», чтобы азан звучал вовремя с выбранным звуком."), color = Color.White, fontSize = 13.sp)
                    TextButton(onClick = {
                        c.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }) { Text(tr("Ruxsat berish", "Allow", "Разрешить"), color = Color(0xFFFFD27A)) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text(tr("Keyingi namoz", "Next prayer", "Следующий намаз"), color = MaterialTheme.colorScheme.onPrimary, fontSize = 14.sp)
                Text("${pName(nextI)}  ${fmt(times[nextI])}", color = MaterialTheme.colorScheme.onPrimary, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("%02d:%02d:%02d".format(left / 3600, left / 60 % 60, left % 60), color = MaterialTheme.colorScheme.onPrimary, fontSize = 22.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        for (i in 0..5) {
            var on by remember(i, ver) { mutableStateOf(Prefs.bool(c, "n$i", true)) }
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp))
                .background(if (i == nextI) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface)
                .padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(pName(i), Modifier.weight(1f), fontSize = 18.sp)
                Text(fmt(times[i]), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                if (i != 1) Text(if (on) "🔔" else "🔕", fontSize = 22.sp, modifier = Modifier.padding(start = 16.dp).clickable {
                    on = !on; Prefs.put(c, "n$i", on); Sched.schedule(c)
                }) else Spacer(Modifier.width(38.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("🌙 " + tr("Ramazon", "Ramadan", "Рамадан"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("${tr("Saharlik", "Suhoor ends", "Сухур")}: ${fmt(times[0])}     ${tr("Iftor", "Iftar", "Ифтар")}: ${fmt(times[4])}", fontSize = 16.sp)
            }
        }
    }
    if (showCity) AlertDialog(onDismissRequest = { showCity = false }, confirmButton = {},
        title = { Text(tr("Shahar tanlang", "Choose city", "Выберите город")) },
        text = {
            LazyColumn {
                item { TextButton(onClick = { showCity = false; perm.launch(Manifest.permission.ACCESS_COARSE_LOCATION) }) { Text("📡 GPS") } }
                items(CITIES) { ct ->
                    Text(uzt(ct.name), Modifier.fillMaxWidth().clickable {
                        Prefs.put(c, "mode", "city"); Prefs.put(c, "city", ct.name); Sched.schedule(c); PrayerWidget.refresh(c)
                        ver++; showCity = false
                    }.padding(vertical = 12.dp), fontSize = 18.sp)
                }
            }
        })
}

// ---------------- QIBLA ----------------
@Composable
fun QiblaScreen() {
    val c = LocalContext.current
    val (name, lat, lng) = remember { Loc.get(c) }
    val bearing = remember { qiblaBearing(lat, lng) }
    val decl = remember { GeomagneticField(lat.toFloat(), lng.toFloat(), 0f, System.currentTimeMillis()).declination }
    var az by remember { mutableFloatStateOf(0f) }
    var hasSensor by remember { mutableStateOf(true) }
    DisposableEffect(Unit) {
        val sm = c.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val r = FloatArray(9); SensorManager.getRotationMatrixFromVector(r, e.values)
                val o = FloatArray(3); SensorManager.getOrientation(r, o)
                val a = ((Math.toDegrees(o[0].toDouble()) + decl + 360) % 360).toFloat()
                var d = a - az; if (d > 180) d -= 360; if (d < -180) d += 360
                az = (az + d * 0.25f + 360) % 360
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (s != null) sm.registerListener(l, s, SensorManager.SENSOR_DELAY_UI) else hasSensor = false
        onDispose { sm.unregisterListener(l) }
    }
    val diff = ((bearing - az + 540) % 360 - 180).toFloat()
    val ok = kotlin.math.abs(diff) < 5f
    val col = if (ok) Color(0xFF3DB46D) else MaterialTheme.colorScheme.primary
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(tr("Qibla burchagi", "Qibla angle", "Угол киблы") + ": %.0f°".format(bearing), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("📍 ${if (name == "GPS") "GPS" else uzt(name)}")
        Spacer(Modifier.height(24.dp))
        Box(Modifier.size(300.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val r = size.minDimension / 2 - 8f
                drawCircle(col, r, style = Stroke(8f))
                rotate(-az) { drawLine(Color(0xFFD9534F), center, Offset(center.x, center.y - r), 6f, StrokeCap.Round) } // shimol
                rotate(diff) {
                    drawLine(col, center, Offset(center.x, center.y - r * 0.85f), 16f, StrokeCap.Round)
                    drawCircle(col, 22f, Offset(center.x, center.y - r * 0.85f))
                }
            }
            Text("🕋", fontSize = 40.sp)
        }
        Spacer(Modifier.height(16.dp))
        Text(if (ok) "✅ " + tr("Qibla tomon", "Facing Qibla", "Вы лицом к кибле") else "%.0f°".format(az), fontSize = 20.sp)
        if (!hasSensor) Text(tr("Telefoningizda kompas sensori yo'q. Faqat burchakdan foydalaning.", "No compass sensor. Use the angle only.", "Нет датчика компаса. Используйте только угол."))
        Text(tr("Telefonni tekis ushlang; kerak bo'lsa 8 shaklida aylantirib kalibrlang.", "Hold the phone flat; calibrate by moving it in a figure 8.", "Держите телефон ровно; при необходимости откалибруйте «восьмёркой»."),
            fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
    }
}

// ---------------- TASBEH ----------------
@Composable
fun TasbehScreen() {
    val c = LocalContext.current
    val hap = LocalHapticFeedback.current
    var zi by remember { mutableIntStateOf(Prefs.int(c, "zi", 0)) }
    var tgt by remember { mutableIntStateOf(Prefs.int(c, "tgt", 33)) }
    var count by remember(zi) { mutableIntStateOf(Prefs.int(c, "cnt$zi", 0)) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ZIKRS.forEachIndexed { i, z ->
                FilterChip(selected = zi == i, onClick = { zi = i; tgt = z.target; Prefs.put(c, "zi", i); Prefs.put(c, "tgt", tgt) }, label = { Text(uzt(z.lat)) })
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(ZIKRS[zi].ar, fontSize = 34.sp, textAlign = TextAlign.Center)
        Text(uzt(ZIKRS[zi].lat), fontSize = 16.sp)
        Spacer(Modifier.height(20.dp))
        Box(Modifier.size(240.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary).clickable {
            count++; Prefs.put(c, "cnt$zi", count)
            hap.performHapticFeedback(if (tgt > 0 && count % tgt == 0) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove)
        }, contentAlignment = Alignment.Center) {
            Text("$count", fontSize = 64.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(33, 99, 100, 0).forEach { t ->
                FilterChip(selected = tgt == t, onClick = { tgt = t; Prefs.put(c, "tgt", t) }, label = { Text(if (t == 0) "∞" else "$t") })
            }
        }
        if (tgt > 0) Text("${count % tgt} / $tgt   (×${count / tgt})", Modifier.padding(top = 8.dp))
        OutlinedButton(onClick = { count = 0; Prefs.put(c, "cnt$zi", 0) }, modifier = Modifier.padding(top = 12.dp)) {
            Text(tr("Nolga qaytarish", "Reset", "Сбросить"))
        }
    }
}

// ---------------- DUO + ISMLAR ----------------
@Composable
fun DuaScreen() {
    val c = LocalContext.current
    var sub by remember { mutableIntStateOf(0) }
    val names = remember { c.assets.open("names.txt").bufferedReader().readLines().filter { it.isNotBlank() }.map { it.split("|") } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = sub == 0, onClick = { sub = 0 }, label = { Text(tr("Duolar", "Duas", "Дуа")) })
            FilterChip(selected = sub == 1, onClick = { sub = 1 }, label = { Text(tr("Alloh ismlari", "99 Names", "99 имён")) })
        }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (sub == 0) items(DUAS) { d ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(pick(d.title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(d.ar, fontSize = 26.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), textAlign = TextAlign.End)
                        Text(uzt(d.lat), fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                        Text(pick(d.tr), Modifier.padding(top = 6.dp))
                    }
                }
            } else items(names.size) { i ->
                val n = names[i]
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}", Modifier.width(36.dp), color = MaterialTheme.colorScheme.primary)
                        Column(Modifier.weight(1f)) {
                            Text(uzt(n[1]), fontWeight = FontWeight.SemiBold)
                            if (langState.startsWith("uz")) Text(uzt(n[2]), fontSize = 13.sp)
                        }
                        Text(n[0], fontSize = 24.sp)
                    }
                }
            }
        }
    }
}

// ---------------- SOZLAMALAR ----------------
@Composable
fun Head(t: String) = Text(t, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary,
    modifier = Modifier.padding(top = 18.dp, bottom = 4.dp))

@Composable
fun Stepper(label: String, value: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        OutlinedButton(onClick = { onChange(value - 1) }) { Text("−") }
        Text(if (value > 0) "+$value" else "$value", Modifier.padding(horizontal = 12.dp))
        OutlinedButton(onClick = { onChange(value + 1) }) { Text("+") }
    }
}

@Composable
fun Radio(sel: Boolean, label: String, onClick: () -> Unit) =
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = sel, onClick = null); Text(label, Modifier.padding(start = 8.dp))
    }

@Composable
fun SettingsScreen() {
    val c = LocalContext.current
    fun changed() { Sched.schedule(c); PrayerWidget.refresh(c) }
    var fa by remember { mutableIntStateOf(Prefs.int(c, "fa", 18)) }
    var ia by remember { mutableIntStateOf(Prefs.int(c, "ia", 18)) }
    var hanafi by remember { mutableStateOf(Prefs.bool(c, "hanafi", true)) }
    var snd by remember { mutableIntStateOf(Prefs.int(c, "snd", 0)) }
    var hadj by remember { mutableIntStateOf(Prefs.int(c, "hadj", 0)) }
    var offs by remember { mutableStateOf(List(6) { Prefs.int(c, "off$it", if (it == 4) 5 else 0) }) }
    var sndName by remember { mutableStateOf(Prefs.str(c, "sndname", "")) }
    var vol by remember { mutableFloatStateOf(Prefs.int(c, "vol", 100) / 100f) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) kotlin.concurrent.thread {
            val nm = copyAdhan(c, uri)
            if (nm != null) { Prefs.put(c, "sndname", nm); Prefs.put(c, "snd", 1); sndName = nm; snd = 1 }
            else android.os.Handler(android.os.Looper.getMainLooper()).post {
                Toast.makeText(c, tr("Fayl 30 MB dan katta yoki o'qib bo'lmadi", "File is over 30 MB or unreadable", "Файл больше 30 МБ или не читается"), Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Head(tr("Til", "Language", "Язык"))
        LANGS.forEach { (code, nm) -> Radio(langState == code, nm) { langState = code; Prefs.put(c, "lang", code); PrayerWidget.refresh(c) } }

        Head(tr("Hisoblash usuli", "Calculation method", "Метод расчёта"))
        Radio(fa == 18 && ia == 18, "O'zbekiston / Karachi (18° / 18°)".let { uzt(it) }) { fa = 18; ia = 18; Prefs.put(c, "fa", 18); Prefs.put(c, "ia", 18); changed() }
        Radio(fa == 18 && ia == 17, "Muslim World League (18° / 17°)") { fa = 18; ia = 17; Prefs.put(c, "fa", 18); Prefs.put(c, "ia", 17); changed() }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Hanafi Asr (soya 2 barobar)", "Hanafi Asr (shadow ×2)", "Ханафитский Аср (тень ×2)"), Modifier.weight(1f))
            Switch(checked = hanafi, onCheckedChange = { hanafi = it; Prefs.put(c, "hanafi", it); changed() })
        }

        Head(tr("±daqiqa tuzatish", "± minute adjustment", "Коррекция ± минут"))
        for (i in 0..5) Stepper(pName(i), offs[i]) { v ->
            offs = offs.toMutableList().also { it[i] = v }; Prefs.put(c, "off$i", v); changed()
        }
        Stepper(tr("Hijriy sana (±kun)", "Hijri date (± day)", "Хиджра (± день)"), hadj) { v -> hadj = v.coerceIn(-2, 2); Prefs.put(c, "hadj", hadj) }

        Head(tr("Azon signali", "Adhan alert", "Сигнал азана"))
        Radio(snd == 0, tr("Standart budilnik signali", "Default alarm sound", "Стандартный сигнал будильника")) { snd = 0; Prefs.put(c, "snd", 0) }
        Radio(snd == 1, tr("Mening faylim", "My own file", "Мой файл") + if (sndName.isNotEmpty()) ": $sndName" else "") {
            if (sndName.isEmpty()) pick.launch(arrayOf("audio/*")) else { snd = 1; Prefs.put(c, "snd", 1) }
        }
        Radio(snd == 2, tr("Faqat bildirishnoma (jim rejimda chalinmaydi)", "Notification only (silent in silent mode)", "Только уведомление (без звука в беззвучном режиме)")) { snd = 2; Prefs.put(c, "snd", 2) }
        OutlinedButton(onClick = { pick.launch(arrayOf("audio/*")) }) { Text(tr("Audio fayl tanlash", "Choose audio file", "Выбрать аудиофайл")) }
        Text(tr("Azon ovozi balandligi", "Adhan volume", "Громкость азана") + ": ${(vol * 100).toInt()}%", Modifier.padding(top = 8.dp))
        Slider(value = vol, onValueChange = { vol = it; Prefs.put(c, "vol", (it * 100).toInt()) }, valueRange = 0.1f..1f)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { Notifier.show(c, 0) }) { Text(tr("Sinab ko'rish", "Test", "Проверить")) }
            OutlinedButton(onClick = { c.startService(Intent(c, AdhanService::class.java).setAction("STOP")) }) { Text(tr("To'xtatish", "Stop", "Остановить")) }
        }
        Text(tr("Azon budilnik ovoz oqimida chaladi: telefon jim (sound off) rejimida va «Bezovta qilmang» rejimida (Budilniklar ruxsat etilgan bo'lsa) ham eshitiladi. «To'liq sukunat» rejimida chalinmaydi. Telefon budilnik ovozi 0 bo'lsa ham, ilovadagi balandlik bilan chalinadi, lekin juda past bo'lishi mumkin.",
            "The adhan plays on the alarm stream, so it is audible in silent mode and in Do Not Disturb (when Alarms are allowed). It will not play in «Total silence». If the phone's alarm volume is very low, the adhan will be quiet too.",
            "Азан звучит через поток будильника: слышен в беззвучном режиме и в режиме «Не беспокоить» (если разрешены будильники). В режиме «Полная тишина» не звучит. Если громкость будильника очень низкая, азан тоже будет тихим."),
            fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))

        Head(tr("Bildirishnoma o'z vaqtida kelishi uchun", "For on-time notifications", "Для своевременных уведомлений"))
        Button(onClick = { c.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
            Text(tr("Batareya sozlamasi", "Battery settings", "Настройки батареи"))
        }
        if (Build.VERSION.SDK_INT >= 31) Button(onClick = {
            c.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }, modifier = Modifier.padding(top = 4.dp)) { Text(tr("Aniq signal ruxsati", "Exact alarm permission", "Разрешение точных будильников")) }
        Text(tr("Xiaomi/Oppo/Vivo/Samsung: ilovani «Cheklovsiz» (No restrictions) rejimiga o'tkazing va «Avtoishga tushirish»ni yoqing. Aks holda bildirishnoma kechikishi mumkin.",
            "Xiaomi/Oppo/Vivo/Samsung: set the app to «No restrictions» and enable Autostart. Otherwise notifications may be delayed.",
            "Xiaomi/Oppo/Vivo/Samsung: выберите «Без ограничений» и включите автозапуск, иначе уведомления могут запаздывать."),
            fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(24.dp))
        Text("v1.0.0", fontSize = 12.sp)
    }
}

fun copyAdhan(c: Context, uri: Uri): String? {
    return try {
        var name = "audio"; var size = 0L
        c.contentResolver.query(uri, null, null, null, null)?.use { q ->
            if (q.moveToFirst()) {
                val ni = q.getColumnIndex(OpenableColumns.DISPLAY_NAME); val si = q.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = q.getString(ni) ?: name
                if (si >= 0) size = q.getLong(si)
            }
        }
        if (size > 30_000_000L) return null
        val ok = c.contentResolver.openInputStream(uri)?.use { i -> File(c.filesDir, "adhan_custom").outputStream().use { o -> i.copyTo(o) } }
        if (ok == null) null else name
    } catch (e: Exception) { null }
}
