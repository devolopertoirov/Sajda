package uz.tasbehduo.app

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Sahifalar: assets/quran/<kitob>/001.webp, 002.webp ...  Mavjud papkalar avtomatik topiladi.
@Composable
fun QuranScreen() {
    val c = LocalContext.current
    val books = remember {
        listOf("madani" to "Qur'on (Madina yozuvi)", "tajweed" to "Tajvidli Qur'on (rangli)")
            .filter { (id, _) -> (c.assets.list("quran/$id")?.size ?: 0) > 0 }
    }
    if (books.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(tr("Qur'on sahifalari qo'shilmagan.", "Quran pages are not included.", "Страницы Корана не добавлены."))
        }
        return
    }
    var bi by remember { mutableIntStateOf(books.indexOfFirst { it.first == Prefs.str(c, "qbook", "") }.coerceAtLeast(0)) }
    Column(Modifier.fillMaxSize()) {
        if (books.size > 1) Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            books.forEachIndexed { i, (id, title) ->
                FilterChip(selected = bi == i, onClick = { bi = i; Prefs.put(c, "qbook", id) }, label = { Text(uzt(title)) })
            }
        }
        key(books[bi].first) { QuranPager(books[bi].first) }
    }
}

@Composable
fun QuranPager(book: String) {
    val c = LocalContext.current
    val total = remember(book) { c.assets.list("quran/$book")?.size ?: 0 }
    val state = rememberPagerState(initialPage = Prefs.int(c, "qpage_$book", 0).coerceIn(0, (total - 1).coerceAtLeast(0))) { total }
    val scope = rememberCoroutineScope()
    var zoom by remember { mutableStateOf(false) }
    var jump by remember { mutableStateOf(false) }
    LaunchedEffect(state.currentPage) { Prefs.put(c, "qpage_$book", state.currentPage) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${state.currentPage + 1} / $total", Modifier.clickable { jump = true }, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary, fontSize = 16.sp)
            Spacer(Modifier.weight(1f))
            Text(if (zoom) "🔍−" else "🔍+", Modifier.clickable { zoom = !zoom }, fontSize = 20.sp)
        }
        // Qur'on o'ngdan chapga: 1-sahifa o'ngda, keyingisi uchun barmoqni chapdan o'ngga suring
        HorizontalPager(state, Modifier.fillMaxSize(), reverseLayout = true, userScrollEnabled = !zoom) { p ->
            QuranPage(book, p, zoom) { zoom = !zoom }
        }
    }
    if (jump) {
        var txt by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { jump = false },
            confirmButton = {
                TextButton(onClick = {
                    txt.toIntOrNull()?.let { n -> scope.launch { state.scrollToPage((n - 1).coerceIn(0, total - 1)) } }
                    jump = false
                }) { Text("OK") }
            },
            title = { Text(tr("Sahifaga o'tish", "Go to page", "Перейти на страницу")) },
            text = {
                OutlinedTextField(value = txt, onValueChange = { txt = it.filter(Char::isDigit).take(4) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), placeholder = { Text("1 – $total") })
            })
    }
}

@Composable
fun QuranPage(book: String, p: Int, zoom: Boolean, onDoubleTap: () -> Unit) {
    val c = LocalContext.current
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, book, p) {
        value = withContext(Dispatchers.IO) {
            try { c.assets.open("quran/$book/%03d.webp".format(p + 1)).use { BitmapFactory.decodeStream(it)?.asImageBitmap() } }
            catch (e: Exception) { null }
        }
    }
    val sw = LocalConfiguration.current.screenWidthDp.dp
    val hs = rememberScrollState(); val vs = rememberScrollState()
    Box(Modifier.fillMaxSize().background(Color.White)
        .then(if (zoom) Modifier.horizontalScroll(hs) else Modifier)
        .verticalScroll(vs)
        .pointerInput(Unit) { detectTapGestures(onDoubleTap = { onDoubleTap() }) }) {
        bmp?.let { Image(it, null, Modifier.width(if (zoom) sw * 2 else sw), contentScale = ContentScale.FillWidth) }
    }
}
