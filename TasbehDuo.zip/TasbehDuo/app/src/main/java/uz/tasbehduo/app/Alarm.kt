package uz.tasbehduo.app

import android.app.*
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.content.pm.ServiceInfo
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.content.ContextCompat
import java.io.File
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.time.LocalDate
import java.time.ZoneId

val ALARM_IDX = listOf(0, 2, 3, 4, 5) // Quyosh uchun azon yo'q

object Sched {
    fun minutes(c: Context, d: LocalDate): IntArray {
        val (_, lat, lng) = Loc.get(c)
        val h = Calc.hours(d, lat, lng, Prefs.int(c, "fa", 18).toDouble(), Prefs.int(c, "ia", 18).toDouble(), Prefs.bool(c, "hanafi", true))
        return IntArray(6) { Math.round(h[it] * 60).toInt() + Prefs.int(c, "off$it", if (it == 4) 5 else 0) }
    }

    fun next(c: Context): Pair<Int, Long>? {
        val now = System.currentTimeMillis(); val zone = ZoneId.systemDefault()
        for (day in 0..2) {
            val d = LocalDate.now().plusDays(day.toLong()); val t = minutes(c, d)
            val start = d.atStartOfDay(zone).toInstant().toEpochMilli()
            for (i in ALARM_IDX) {
                if (!Prefs.bool(c, "n$i", true)) continue
                val ms = start + t[i] * 60000L
                if (ms > now + 1000) return i to ms
            }
        }
        return null
    }

    fun schedule(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(c, 1, Intent(c, AlarmReceiver::class.java).putExtra("i", next(c)?.first ?: 0),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = next(c)
        if (n == null) { am.cancel(pi); return }
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, n.second, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, n.second, pi)
    }
}

object Notifier {
    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("adhan_v1", "Azon (ovoz chalinmoqda)", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null); enableVibration(false)
        })
        nm.createNotificationChannel(NotificationChannel("note", "Bildirishnoma", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build())
            enableVibration(true)
        })
        nm.createNotificationChannel(NotificationChannel("alarm_fb", "Azon (zaxira)", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            enableVibration(true)
        })
    }

    fun builder(c: Context, i: Int, ch: String, category: String): NotificationCompat.Builder =
        NotificationCompat.Builder(c, ch)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(pName(i))
            .setContentText(tr("Namoz vaqti bo'ldi", "It is time for prayer", "Наступило время намаза"))
            .setCategory(category)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))

    private fun plain(c: Context, i: Int, ch: String, category: String) {
        try { NotificationManagerCompat.from(c).notify(100 + i, builder(c, i, ch, category).setAutoCancel(true).build()) }
        catch (e: SecurityException) { }
    }

    fun show(c: Context, i: Int) {
        channels(c)
        if (Prefs.int(c, "snd", 0) == 2) { plain(c, i, "note", NotificationCompat.CATEGORY_REMINDER); return }
        try {
            ContextCompat.startForegroundService(c, Intent(c, AdhanService::class.java).putExtra("i", i))
        } catch (e: Exception) {
            plain(c, i, "alarm_fb", NotificationCompat.CATEGORY_ALARM) // zaxira: tizim budilnik ovozi
        }
    }
}

// Azonni ALARM oqimida chaladi: jim rejimda va "Bezovta qilmang" (Alarms ruxsat etilgan) rejimida ham eshitiladi.
class AdhanService : Service() {
    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private val stopper = Runnable { stopSelf() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        loadLang(this)
        Notifier.channels(this)
        val i = intent?.getIntExtra("i", 0) ?: 0
        val stop = PendingIntent.getService(this, 2, Intent(this, AdhanService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notifier.builder(this, i, "adhan_v1", NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .addAction(0, tr("To'xtatish", "Stop", "Остановить"), stop)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(100 + i, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(100 + i, n)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        play()
        h.removeCallbacks(stopper); h.postDelayed(stopper, 5 * 60 * 1000L)
        return START_NOT_STICKY
    }

    private fun play() {
        mp?.release(); mp = null
        val file = File(filesDir, "adhan_custom")
        val custom = Prefs.int(this, "snd", 0) == 1 && file.exists()
        if (custom && start { it.setDataSource(file.absolutePath) }) return
        if (!start { it.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)) }) stopSelf()
    }

    private fun start(src: (MediaPlayer) -> Unit): Boolean {
        val m = MediaPlayer()
        return try {
            m.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            m.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            src(m)
            val v = Prefs.int(this, "vol", 100) / 100f
            m.setVolume(v, v)
            m.setOnCompletionListener { stopSelf() }
            m.prepare(); m.start(); mp = m; true
        } catch (e: Exception) { m.release(); false }
    }

    override fun onDestroy() {
        h.removeCallbacks(stopper)
        mp?.release(); mp = null
        super.onDestroy()
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        loadLang(c)
        Notifier.show(c, intent.getIntExtra("i", 0))
        Sched.schedule(c)
        PrayerWidget.refresh(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        Sched.schedule(c)
        PrayerWidget.refresh(c)
    }
}

class PrayerWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, build(c))
    }

    companion object {
        fun build(c: Context): RemoteViews {
            loadLang(c)
            val rv = RemoteViews(c.packageName, R.layout.widget)
            val now = java.time.LocalTime.now(); val nowM = now.hour * 60 + now.minute
            val today = Sched.minutes(c, LocalDate.now())
            var idx = -1; var tm = 0
            for (i in ALARM_IDX) if (today[i] > nowM) { idx = i; tm = today[i]; break }
            if (idx < 0) { idx = 0; tm = Sched.minutes(c, LocalDate.now().plusDays(1))[0] }
            rv.setTextViewText(R.id.w_name, pName(idx))
            rv.setTextViewText(R.id.w_time, fmt(tm))
            rv.setOnClickPendingIntent(R.id.w_root,
                PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            return rv
        }

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            for (id in m.getAppWidgetIds(ComponentName(c, PrayerWidget::class.java))) m.updateAppWidget(id, build(c))
        }
    }
}
