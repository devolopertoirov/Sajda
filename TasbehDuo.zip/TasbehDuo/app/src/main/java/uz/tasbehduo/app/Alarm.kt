package uz.tasbehduo.app

import android.app.*
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.time.LocalDate
import java.time.ZoneId

val ALARM_IDX = listOf(0, 2, 3, 4, 5) // Quyosh uchun azon yo'q

object Sched {
    fun minutes(c: Context, d: LocalDate): IntArray {
        val (_, lat, lng) = Loc.get(c)
        val h = Calc.hours(d, lat, lng, Prefs.int(c, "fa", 18).toDouble(), Prefs.int(c, "ia", 18).toDouble(), Prefs.bool(c, "hanafi", true))
        return IntArray(6) { Math.round(h[it] * 60).toInt() + Prefs.int(c, "off$it", if (it == 4) 5 else 0) }
    }

    fun next(c: Context): Pair<Int, Long>? {
        val now = System.currentTimeMillis(); val zone = ZoneId.systemDefault()
        for (day in 0..2) {
            val d = LocalDate.now().plusDays(day.toLong()); val t = minutes(c, d)
            val start = d.atStartOfDay(zone).toInstant().toEpochMilli()
            for (i in ALARM_IDX) {
                if (!Prefs.bool(c, "n$i", true)) continue
                val ms = start + t[i] * 60000L
                if (ms > now + 1000) return i to ms
            }
        }
        return null
    }

    fun schedule(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(c, 1, Intent(c, AlarmReceiver::class.java).putExtra("i", next(c)?.first ?: 0),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = next(c)
        if (n == null) { am.cancel(pi); return }
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, n.second, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, n.second, pi)
    }
}

object Notifier {
    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val defs = listOf(Triple("ch0", RingtoneManager.TYPE_NOTIFICATION, "Notification"),
            Triple("ch1", RingtoneManager.TYPE_ALARM, "Alarm"), Triple("ch2", RingtoneManager.TYPE_RINGTONE, "Ringtone"))
        for ((id, type, name) in defs) {
            val ch = NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH)
            val attrs = AudioAttributes.Builder()
                .setUsage(if (type == RingtoneManager.TYPE_ALARM) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION).build()
            ch.setSound(RingtoneManager.getDefaultUri(type), attrs)
            ch.enableVibration(true)
            nm.createNotificationChannel(ch)
        }
    }

    fun show(c: Context, i: Int) {
        channels(c)
        val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, "ch${Prefs.int(c, "snd", 0)}")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(pName(i))
            .setContentText(tr("Namoz vaqti bo'ldi", "It is time for prayer", "Наступило время намаза"))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).setContentIntent(pi).build()
        try { NotificationManagerCompat.from(c).notify(100 + i, n) } catch (e: SecurityException) { }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        loadLang(c)
        Notifier.show(c, intent.getIntExtra("i", 0))
        Sched.schedule(c)
        PrayerWidget.refresh(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        Sched.schedule(c)
        PrayerWidget.refresh(c)
    }
}

class PrayerWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, build(c))
    }

    companion object {
        fun build(c: Context): RemoteViews {
            loadLang(c)
            val rv = RemoteViews(c.packageName, R.layout.widget)
            val now = java.time.LocalTime.now(); val nowM = now.hour * 60 + now.minute
            val today = Sched.minutes(c, LocalDate.now())
            var idx = -1; var tm = 0
            for (i in ALARM_IDX) if (today[i] > nowM) { idx = i; tm = today[i]; break }
            if (idx < 0) { idx = 0; tm = Sched.minutes(c, LocalDate.now().plusDays(1))[0] }
            rv.setTextViewText(R.id.w_name, pName(idx))
            rv.setTextViewText(R.id.w_time, fmt(tm))
            rv.setOnClickPendingIntent(R.id.w_root,
                PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            return rv
        }

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            for (id in m.getAppWidgetIds(ComponentName(c, PrayerWidget::class.java))) m.updateAppWidget(id, build(c))
        }
    }
}
