# Tasbeh Duo Zikr (Android, Kotlin + Jetpack Compose)

## GitHub orqali build
1. Bu papkani GitHub repo'ga yuklang (`main` branch).
2. Actions → "Build" avtomatik ishlaydi (yoki Run workflow).
3. Artifacts → `build-files`: `app-debug.apk` (sinash uchun) va `app-release.aab` (Play Market uchun).

## Play Market uchun imzo (Settings → Secrets → Actions)
`KEYSTORE_BASE64` (keystore faylning base64 ko'rinishi), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
Keystore yaratish: `keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload`
Base64: `base64 -w0 release.jks`. **Keystore'ni yo'qotmang.**

## Almashtirish kerak
- `applicationId` (`app/build.gradle.kts`)
- AdMob App ID (`AndroidManifest.xml`) va Banner ID (`MainActivity.kt`) — hozir TEST ID'lar.
- Duo/zikr matnlari (`Content.kt`) va 99 ism (`assets/names.txt`) — ishonchli manba bilan tekshiring.
